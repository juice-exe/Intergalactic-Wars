Project by:
	Rohan Pandey
=====================================================================================================
Instructions to run the file 'intergalactic_wars.py':
	1. Install the library 'pygame' from the Command Promt. (all other libraries are inbuilt)
	2. open the python file, run and enjoy! :)
=====================================================================================================
Pepe the frog wants to reach the skies but some people don't want that to happen!
	Watchout! Is that THANOS? along with Rick Sanchez & Rick Astley

Enjoy the old school space invation arcade game with a completely new look, welcoming your favourite
	icons from the meme world!

Dodge enemy fire and use cover fire to proceed, and neither let the enemy touch/shoot you nor let them 
	get behind you!

5 crossovers and you loose! Also keep an eye on your ship's health (it's not invincible).
	Just remember - #memesbeatsweats
=====================================================================================================
Controls:
         W
   A     S     D   (movement)

        SPACE         (shoot)
=====================================================================================================